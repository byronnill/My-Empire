package Model;

public abstract class OwnableSpace extends Space {

  protected final int OWNABLE_ID;
  protected final String NAME;
  protected final double PRICE;

  protected Player owner;
  protected double dRent;

  public OwnableSpace (int nLocationIndex, int nID, String strName, double dPrice, double dRent) {

    super(nLocationIndex);

    this.OWNABLE_ID = nID;
    this.owner = null;
    this.NAME = strName;
    this.PRICE = dPrice;
    this.dRent = dRent;

  }

  public boolean canBeBought (Player currPlayer) {

//    if (this instanceof ChanceSpace || this instanceof TaxSpace || this.nLocationIndex == 0 ||
//            this.nLocationIndex == 8 || this.nLocationIndex == 16 || this.nLocationIndex == 24)   //can be removed if options displayed for these spaces are just draw card, pay, or nothing
//      return false;

    return this.owner == null && currPlayer.isPaymentPossible(this.PRICE);

//    else if (this instanceof Railroad)
//      return ((Railroad) this).getOwner() == null && currPlayer.isPaymentPossible(((Railroad) this).getPrice());
//
//    else
//      return ((Utility) this).getOwner() == null && currPlayer.isPaymentPossible(((Utility) this).getPrice());

  }

  public int getID () {
    return OWNABLE_ID;
  }

  public Player getOwner () {
    return owner;
  }

  public String getName () {
    return NAME;
  }

  public double getPrice () {
    return PRICE;
  }

  public double getRent () {
    return dRent;
  }

  public void setOwner (Player owner) {
    this.owner = owner;
  }

  public void setRent (double dRent) {
    this.dRent = dRent;
  }

  @Override
  public String toString () {

    String toReturn = "ID: " + this.OWNABLE_ID +
                      "\nNAME: " + this.NAME;

    try {

      toReturn += "\nOWNER: " + this.owner.getName();

    } catch (NullPointerException e) {

      toReturn += "\nOWNER: NULL";

    }

    toReturn += "\nPRICE: " + this.PRICE +
                "\nRENT: " + this.dRent;

    return toReturn;

  }

}
