package Model;

public class ChanceSpace extends Space {

  public ChanceSpace(int nLocationIndex) {
    super(nLocationIndex);
  }

}
